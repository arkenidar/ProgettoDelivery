package it.arces.provaFb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvaFbApplicationTests {

	@Test
	void contextLoads() {
	}

}
