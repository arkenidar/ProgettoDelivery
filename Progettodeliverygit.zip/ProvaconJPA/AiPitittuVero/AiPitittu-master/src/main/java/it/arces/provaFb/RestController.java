package it.arces.provaFb;

public @interface RestController {

}
